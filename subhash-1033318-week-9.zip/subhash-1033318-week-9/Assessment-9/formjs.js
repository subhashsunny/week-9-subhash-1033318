var unameDom = document.getElementById("uname")
var uemailDom = document.getElementById("uemail")
var btnDom = document.getElementById("btn")
unameDom.addEventListener("input", checkinputs)
uemailDom.addEventListener("input", checkinputs)
//function to get focus on input textbox when page gets loaded
userDom.focus();
//to enable the disabled button
function checkinputs() {
    if (unameDomDom !== "" && uemailDom !== "") {
        btnDom.removeAttribute("disabled");
    } else {
        btnDom.setAttribute("disable", "true");
    }
}
//function to validate the password.
btnDom.addEventListener("click",btnfun);
function btnfun(){
    uservalue=userDom.value;
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(uservalue);
    if (validRegex) {
      window.location.href="https://www.google.com/";
    } else {
    var valid="*you must use a valid email address or userId";
    //you must use a valid email address or userId
    document.getElementById("uservalidate").innerHTML=valid;
    }
}
